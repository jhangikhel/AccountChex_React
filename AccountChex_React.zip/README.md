# eshop-ui-react

Download and run the application by following these steps: 

1. Select the master branch of eshop-ui-react
2. Click on "Clone or Download" button of eshop-ui-react master branch
3. Then click on "Download Zip" button to download the project folder as zip.
4. Extract these files
5. Now Open Command Prompt(For Windows)
6. Move to Root Folder, where the project is extracted.
7. Now Run the command npm install
8. Now Run the commmand npm start
9. Now Open the Browser
10. Now Type URL http://localhost:3000

