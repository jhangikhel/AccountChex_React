import React from 'react';

const ComingSoon = () => {
    return (
        <React.Fragment>
            Comming Soon
        </React.Fragment>
    );
};

export default ComingSoon;